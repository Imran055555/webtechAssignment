<?php
	$gender="";
	if(isset($_GET['error'])){
		echo $_GET['error'];
		
	}
?>
<html>
	<form method="post" action="RegCheck.php">
		<fieldset>
			<legend><b>REGISTRATION FORM</b></legend>
			<table border="0">
			<tr>
				<td> <b>First Name :</b></td>
				<td><input type="text" name="firstName" /> <br/></td>
			</tr>
			<tr>
				<td> <b>Last Name :</b></td>
				<td><input type="text" name="secondName" /><br/></td>
			</tr>
			<tr>
				<td><b>Date Of Birth :</b></td>
				<td><select name = "month">
						<option>Month</option>
							<?php
								for($month = 1; $month <= 12; $month++)
								echo"<option value = '".$month."'>".$month."</option>";
							?>
					</select><br/>
					<select name = "date">
						<option>Day</option>
							<?php
								for($day = 1; $day <= 31; $day++){
								echo "<option value = '".$day."'>".$day."</option>";
								}
							?>
					</select>
					<select name = "year">
						<option>Year</option>
							<?php
								$y = date("Y", strtotime("+8 HOURS"));
								for($year = 1950; $y >= $year; $y--){
								echo "<option value = '".$y."'>".$y."</option>";
								}
							?>
					</select>
				</td>
			</tr>
			<tr>
				<td><b> Gender :</b></td>
				<td>
					<input type="radio" name="gender" value="Male" <?php if("Male" == $gender){ echo "checked";} ?> />Male<br/>
					<input type="radio" name="gender" value="Female" <?php if("Male" == $gender){ echo "checked";} ?> />Female<br/>
					<input type="radio" name="gender" value="Others" <?php if("Male" == $gender){ echo "checked";} ?> />Others<br/>
				</td>
			</tr>
			<tr>
				<td><b>Phone :</b></td>
				<td><input type="number" name="phone" value=""/><br/></td>
			</tr>
			<tr>
				<td> <b>Email ID :</b></td>
				<td><input type="text" name="email" value=""/><br/></td>
			</tr>
			<tr>
				<td><b>Password :</b></td>
				<td><input type="password" name="pass" value=""/><br/></td>
			</tr>
			<tr>
				<td><b>Confirm password :</b></td>
				<td><input type="password" name="repass" value=""/><br/></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Submit"/><br/></td>
			</tr>
			<tr>
				<td>HINT :[First Name should be "imran" & secondName should be "hossain"]</td>
				<td>[Password & repassword also need to be "imran"] [Year must be within 2016]<br/></td>
			</tr>
			</table>
		</fieldset>
	</form>
</html>